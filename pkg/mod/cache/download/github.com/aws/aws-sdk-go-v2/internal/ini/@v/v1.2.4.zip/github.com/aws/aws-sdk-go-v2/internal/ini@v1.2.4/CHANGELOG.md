# v1.2.4 (2021-10-11)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.3 (2021-09-17)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.2 (2021-08-27)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.1 (2021-08-19)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.2.0 (2021-08-04)

* **Feature**: adds error handling for defered close calls
* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.1 (2021-07-15)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.1.0 (2021-07-01)

* **Feature**: Support for `:`, `=`, `[`, `]` being present in expression values.

# v1.0.1 (2021-06-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.0.0 (2021-05-20)

* **Release**: The `github.com/aws/aws-sdk-go-v2/internal/ini` package is now a Go Module.
* **Dependency Update**: Updated to the latest SDK module versions

