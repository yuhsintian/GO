// Package presignedurl provides the customizations for API clients to fill in
// presigned URLs into input parameters.
package presignedurl
