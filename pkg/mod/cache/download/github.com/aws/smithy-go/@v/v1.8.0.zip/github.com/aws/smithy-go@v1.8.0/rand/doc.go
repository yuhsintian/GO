// Package rand provides utilities for creating and working with random value
// generators.
package rand
