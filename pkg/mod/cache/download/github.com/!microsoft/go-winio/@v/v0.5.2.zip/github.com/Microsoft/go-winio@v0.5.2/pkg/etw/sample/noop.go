// +build !windows

package main

func main() {}
