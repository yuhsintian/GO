// Package dktest provides an easy way to write integration tests using Docker
//
// dktest is short for dockertest
package dktest
